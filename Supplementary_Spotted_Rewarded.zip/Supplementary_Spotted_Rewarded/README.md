# Supplementary material

**Spotted, Then Rewarded: Congolese Teacher Educators Recognize AI-Written Answers, Grade Them Higher, and Weakly Agree on the Assessment Formats They Would Trust** (A2MRA 2027)

This archive contains the survey instrument, the anonymized coded data, codebooks, an implementation of the Mean-Median Compromise Method (MMCM) and the code that reproduces every number, table and figure in the paper.

## Contents

| Path | Content |
|---|---|
| `materials/questionnaire_enseignants_FR.pdf` (`.md`) | Teacher questionnaire as administered on Google Forms, in French (version 1). Version 2 is identical except that the six texts of section E appear in the order T6 to T1. |
| `materials/codebook_enseignants_codes.pdf` (`.csv`) | Definition and coding of each variable in `data/enseignants_codes.csv`. |
| `materials/codebook_notes_format_long.pdf` (`.csv`) | Same for `results/notes_format_long.csv`. |
| `data/enseignants_codes.csv` | Coded responses of the 47 consenting teachers (version 1: 25; version 2: 22), one row per teacher. |
| `code/clean.py` | Recodes and merges the two versions of the questionnaire. The raw exports are not distributed (see below). |
| `code/mmcm.py` | Mean-Median Compromise Method (Ngoie et al., *Mathematics* 2024, 12, 3631; correction 2026, 14, 3260). `python code/mmcm.py` checks the worked examples of the original article. |
| `code/analyse_enseignants.py` | Descriptive statistics, signal detection indices (log-linear correction), paired Wilcoxon test and linear mixed model of marks, ROC-weighted aggregation of format rankings with MMCM, range voting, median grade and Copeland's rule, Kendall's W, bootstrap stability, Figures 1 and 2. |
| `code/inferences_enseignants.py` | Cluster-bootstrap intervals for hit and false-alarm rates, d' and the grading premium; order-effect tests (Mann-Whitney, GEE); intraclass correlation; suspicion effect with text fixed effects and on AI texts only; treatment of "don't know" answers; Cronbach's alpha with Feldt intervals; bootstrap intervals of Kendall's W; sign test and MMCM difference between the two leading formats; disclosure of AI use (Wilson intervals). |
| `results/` | Outputs of the analysis scripts: `resultats_enseignants.json`, `inferences_enseignants.json`, `notes_format_long.csv` (282 marks in long format, used by the mixed models), `fig_detection.pdf` (Figure 1) and `fig_bootstrap.pdf` (Figure 2). |

## Reproducing the results

From this folder:

```
pip install -r requirements.txt
python code/mmcm.py
python code/analyse_enseignants.py data/enseignants_codes.csv results
python code/inferences_enseignants.py data/enseignants_codes.csv results
```

The third script reads `results/notes_format_long.csv`, written by the second, so the order matters. The random seed is fixed (20261025). With Python 3.13, NumPy 2.5, pandas 3.0, SciPy 1.18, statsmodels 0.15 and matplotlib 3.11, the JSON files obtained from this archive are byte-identical to those used for the paper. Reproduction was checked only with these versions.

The count of cues cited in teachers' comments (paper, Section 4.3) uses the free-text comments, which are not distributed. The corresponding block of `inferences_enseignants.py` runs only when the comment columns (`T1_motif` to `T6_motif`) are present.

## Detection test

All six texts answer the same examination question: explain in 10 to 15 lines the difference between formative and summative assessment, with an example from a class you know.

| Text | True source | Position in version 1 | Position in version 2 |
|---|---|---|---|
| T1 | chatbot (Claude) | 1 | 6 |
| T2 | second-year student | 2 | 5 |
| T3 | second-year student | 3 | 4 |
| T4 | chatbot (Claude) | 4 | 3 |
| T5 | chatbot (Claude) | 5 | 2 |
| T6 | second-year student | 6 | 1 |

The chatbot texts are 156 to 165 words long and the student copies 111 to 134 words.

The student copies were written on paper, without phones, and typed with their errors. Respondents were not told how many texts came from each source. A debriefing message revealed the composition of the set.

## Data protection

The questionnaire collected no name, e-mail address or other identifier. The distributed file excludes the time stamps and the free-text answers (comments justifying each judgement, suggested institutional measures), which could identify respondents. The raw exports are kept by the authors and can be made available to reviewers for verification on request.
